'use strict';

var colors = [
    { name: 'Electric red', css: 'item-color color-red' },
    { name: 'Blueviolet', css: 'item-color color-blueviolet' },
    { name: 'Black', css: 'item-color color-black' },
    { name: 'White', css: 'item-color color-white' },
    { name: 'Orangered', css: 'item-color color-orangered' },
    { name: 'Yellow', css: 'item-color color-yellow' },
    { name: 'Blue', css: 'item-color color-blue' },
    { name: 'Darkblue', css: 'item-color color-darkblue' },
    { name: 'Lightpink', css: 'item-color color-lightpink' },
    { name: 'Lightblue', css: 'item-color color-lightblue' },
    { name: 'Green', css: 'item-color color-green' },
    { name: 'Pink', css: 'item-color color-pink' },
    { name: 'Lightpink', css: 'item-color color-lightpink' },
    { name: 'Darkblue', css: 'item-color color-darkblue' },
    { name: 'Lightgrey', css: 'item-color color-lightgrey' },
    { name: 'Brown', css: 'item-color color-brown' },
    { name: 'Lightblue', css: 'item-color color-lightblue' },
    { name: 'Lightgrey', css: 'item-color color-lightgrey' }
];
var selectedColor = null;
var selectedQuantity = 0;
var cartColors = [];
var selectedItem = null;

function loadColors() {
    let colorsContainer = document.getElementById('colors-container');
    colors.forEach((color, index) => {
        console.log('Load: ' + color);
        colorsContainer.innerHTML += `<div data-name='${color.name}' onclick="selectColor(${index})" class='${color.css}'></div>`;
    });
}

function selectColor(colorIndex) {
    let colorName = '--';
    if (colorIndex >= 0) {
        selectedColor = colors[colorIndex];
        console.log('Selected: ' + JSON.stringify(selectedColor));
        colorName = selectedColor.name != null ? selectedColor.name : '--';
    }
    selectedQuantity = 0;
    document.getElementById('color-name').innerText = colorName;
    document.getElementById('display-name').innerText = colorName;
    loadCart();
}

function loadCart() {
    var cartButton = document.getElementById('cart-button');
    var checkoutButton = document.getElementById('checkout-button');
    if (cartColors.length > 0) {
        cartButton.style.display = 'none';
        checkoutButton.style.display = 'block';
    } else {
        checkoutButton.style.display = 'none';
        cartButton.style.display = 'block';
    }
    document.getElementById('cart-quantity-value').value = selectedQuantity;
    document.getElementById('quantity-value').innerText = selectedQuantity;
    console.log('Cart: ' + cartColors.length);

    let colorsContainer = document.getElementById('cart-colors-container');
    var cartColorsContainer = '';
    cartColors.forEach((color, index) => {
        console.log('Cart: ' + color);
        cartColorsContainer += `<div data-name='${color.name}' onclick="" class='${color.css}'></div>`;
    });
    colorsContainer.innerHTML = cartColorsContainer;
}

function incrementQuatity() {
    selectedQuantity++;
    console.log('Qty: ' + selectedQuantity);
    loadCart();
}

function decrementQuatity() {
    if (selectedQuantity>0){
        selectedQuantity--;
    }else{
        selectedQuantity = 0;
    }
    console.log('Qty: ' + selectedQuantity);
    loadCart();
}

function addToCart() {
    for (let index = 0; index < selectedQuantity; index++) {
        cartColors.push(selectedColor);
    }
    selectedColor = null;
    loadCart();
}

function checkoutCart() {
    selectedColor = null;
    selectedQuantity = 0;
    cartColors = [];
    selectColor(-1);
    loadCart();
}
loadColors();
loadCart();